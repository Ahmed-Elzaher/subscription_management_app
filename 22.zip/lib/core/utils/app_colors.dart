import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors
  static const Color primaryBlue = Color(0xFF5B7FFF);
  static const Color primaryPurple = Color(0xFF9B4DFF);
  
  // Background Colors
  static const Color backgroundColor = Color(0xFFF8F9FA);
  static const Color cardBackground = Color(0xFFFFFFFF);
  
  // Text Colors
  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textLight = Color(0xFF9CA3AF);
  
  // Accent Colors
  static const Color accentGreen = Color(0xFF10B981);
  static const Color accentRed = Color(0xFFEF4444);
  static const Color accentOrange = Color(0xFFF59E0B);
  
  // Category Colors
  static const Color categoryAll = Color(0xFF5B7FFF);
  static const Color categoryEntertainment = Color(0xFFFF6B6B);
  static const Color categoryBusiness = Color(0xFF10B981);
  
  // Shadow Color
  static const Color shadowColor = Color(0x1A000000);
  
  // Gradient Colors for Header
  static const LinearGradient headerGradient = LinearGradient(
    colors: [primaryBlue, primaryPurple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
