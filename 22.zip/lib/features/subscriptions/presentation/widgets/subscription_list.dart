import 'package:flutter/material.dart';
import '../../data/models/subscription_model.dart';
import 'subscription_item.dart';
import '../../../../core/utils/app_colors.dart';
import '../../../../core/utils/app_constants.dart';

class SubscriptionList extends StatelessWidget {
  final List<SubscriptionModel> subscriptions;
  final ValueChanged<SubscriptionModel>? onItemTap;
  final Function(String)? onDelete;

  const SubscriptionList({
    super.key,
    required this.subscriptions,
    this.onItemTap,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    if (subscriptions.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.inbox_outlined,
                size: 64,
                color: AppColors.textLight,
              ),
              const SizedBox(height: 16),
              Text(
                'No Subscriptions Found',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Use the + button to add a new plan.',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textLight,
                    ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.symmetric(
        vertical: AppConstants.paddingMedium,
      ),
      itemCount: subscriptions.length,
      itemBuilder: (context, index) {
        final subscription = subscriptions[index];
        return SubscriptionItem(
          subscription: subscription,
          onTap: onItemTap,
          onDelete: onDelete != null ? () => onDelete!(subscription.id) : null,
        );
      },
      separatorBuilder: (context, index) => const SizedBox(height: AppConstants.paddingSmall),
    );
  }
}
