import 'package:flutter/material.dart';
import '../../data/models/subscription_model.dart';
import '../../../../core/utils/app_colors.dart';
import '../../../../core/utils/app_constants.dart';

class SubscriptionItem extends StatelessWidget {
  final SubscriptionModel subscription;
  final ValueChanged<SubscriptionModel>? onTap;
  final VoidCallback? onDelete;

  const SubscriptionItem({
    super.key,
    required this.subscription,
    this.onTap,
    this.onDelete,
  });

  IconData _getIconForSubscription() {
    switch (subscription.name.toLowerCase()) {
      case 'netflix':
        return Icons.movie;
      case 'spotify':
        return Icons.music_note;
      case 'microsoft 365':
        return Icons.workspace_premium;
      case 'adobe creative cloud':
        return Icons.brush;
      case 'disney+':
        return Icons.theater_comedy;
      default:
        return Icons.subscriptions;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingLarge,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
          onTap: onTap != null ? () => onTap!(subscription) : null,
          child: Container(
            padding: const EdgeInsets.all(AppConstants.paddingMedium),
            decoration: BoxDecoration(
              color: AppColors.cardBackground,
              borderRadius: BorderRadius.circular(AppConstants.radiusLarge),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadowColor,
                  blurRadius: AppConstants.elevationSmall,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: isMobile ? 54 : 62,
                  height: isMobile ? 54 : 62,
                  decoration: BoxDecoration(
                    color: AppColors.backgroundColor,
                    borderRadius:
                        BorderRadius.circular(AppConstants.radiusMedium),
                  ),
                  child: Icon(
                    _getIconForSubscription(),
                    color: AppColors.primaryBlue,
                    size: isMobile ? 26 : 30,
                  ),
                ),
                const SizedBox(width: AppConstants.paddingMedium),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        subscription.name,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w700,
                            ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: AppConstants.paddingXSmall),
                      Row(
                        children: [
                          Icon(
                            Icons.calendar_today,
                            size: isMobile ? 14 : 16,
                            color: AppColors.textLight,
                          ),
                          const SizedBox(width: AppConstants.paddingXSmall),
                          Text(
                            'Renews ${subscription.formattedRenewalDate}',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                                  color: AppColors.textLight,
                                  fontSize: isMobile ? 12 : 13,
                                ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${subscription.currency}${subscription.price.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: AppConstants.paddingSmall),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppConstants.paddingSmall,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: subscription.isActive
                            ? AppColors.accentGreen.withValues(alpha: 0.12)
                            : AppColors.accentRed.withValues(alpha: 0.12),
                        borderRadius:
                            BorderRadius.circular(AppConstants.radiusSmall),
                      ),
                      child: Text(
                        subscription.isActive ? 'Active' : 'Inactive',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: subscription.isActive
                                  ? AppColors.accentGreen
                                  : AppColors.accentRed,
                              fontWeight: FontWeight.w600,
                              fontSize: isMobile ? 10 : 11,
                            ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: AppConstants.paddingMedium),
                Icon(
                  Icons.arrow_forward_ios,
                  size: isMobile ? 16 : 18,
                  color: AppColors.textLight,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
