import 'package:flutter/material.dart';
import '../../../../core/utils/app_colors.dart';
import '../../../../core/utils/app_constants.dart';

class CategorySelector extends StatelessWidget {
  final List<String> categories;
  final String selectedCategory;
  final ValueChanged<String> onCategoryChanged;

  const CategorySelector({
    super.key,
    required this.categories,
    required this.selectedCategory,
    required this.onCategoryChanged,
  });

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Entertainment':
        return AppColors.categoryEntertainment;
      case 'Business':
        return AppColors.categoryBusiness;
      default:
        return AppColors.categoryAll;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingLarge,
        vertical: AppConstants.paddingMedium,
      ),
      child: Row(
        children: categories.map((category) {
          final isSelected = selectedCategory == category;
          final chipColor = _getCategoryColor(category);

          return Padding(
            padding: const EdgeInsets.only(right: AppConstants.paddingMedium),
            child: FilterChip(
              label: Text(category),
              selected: isSelected,
              onSelected: (_) => onCategoryChanged(category),
              backgroundColor: isSelected ? chipColor : Colors.transparent,
              side: BorderSide(
                color: isSelected ? chipColor : AppColors.textLight,
                width: 1.5,
              ),
              labelStyle: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: isSelected ? Colors.white : AppColors.textSecondary,
                    fontWeight: FontWeight.w600,
                  ),
              elevation: 0,
              pressElevation: 2,
              padding: const EdgeInsets.symmetric(
                horizontal: AppConstants.paddingMedium,
                vertical: AppConstants.paddingSmall,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
