import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HeaderCard extends StatelessWidget {
  final double totalSpend;
  final String currency;
  final VoidCallback? onAddTapped;
  final VoidCallback? onInsightsTapped;

  const HeaderCard({
    super.key,
    required this.totalSpend,
    this.currency = '\$',
    this.onAddTapped,
    this.onInsightsTapped,
  });

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Container(
      width: 345.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.r),
        boxShadow: const [
          BoxShadow(
              color: Color(0x40000000), offset: Offset(0, 4), blurRadius: 4),
          BoxShadow(
              color: Color(0x121F2687), offset: Offset(0, 8), blurRadius: 32),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8.r),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.r),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFFFFFF), Color(0xFFADB5EB)],
              ),
            ),
            padding: const EdgeInsets.all(1),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(7.r),
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.white, Color(0xFFEAEDFA)],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Total Spend',
                              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                color: const Color(0xFF0A0E29),
                                fontWeight: FontWeight.w700,
                                fontSize: isMobile ? 14.sp : 16.sp,
                                height: 1.1,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Subscription overview and monthly expenses',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                fontSize: 12.sp,
                                color: const Color(0xFF141C52),
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 64.w,
                        height: 64.w,
                        decoration: BoxDecoration(
                          color: const Color(0xFFD6DAF5),
                          borderRadius: BorderRadius.circular(16.r),
                        ),
                        child: const Center(
                          child: Icon(Icons.trending_up,
                              color: Color(0xFF2839A4), size: 30),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Flexible(
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: currency,
                                style: Theme.of(context).textTheme.headlineSmall
                                    ?.copyWith(
                                  color: const Color(0xFF0A0E29),
                                  fontWeight: FontWeight.w700,
                                  fontSize: isMobile ? 20.sp : 24.sp,
                                ),
                              ),
                              TextSpan(
                                text: totalSpend.toStringAsFixed(2),
                                style: Theme.of(context).textTheme.headlineLarge
                                    ?.copyWith(
                                  color: const Color(0xFF0A0E29),
                                  fontWeight: FontWeight.w700,
                                  fontSize: isMobile ? 28.sp : 32.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFD6DAF5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'This Month',
                          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF2839A4),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: onAddTapped,
                          icon: const Icon(Icons.add),
                          label: const Text('Add Subscription'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFD6DAF5),
                            foregroundColor: const Color(0xFF2839A4),
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        height: 48,
                        width: 48,
                        decoration: BoxDecoration(
                          color: const Color(0xFFD6DAF5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: IconButton(
                          onPressed: onInsightsTapped,
                          icon: const Icon(Icons.insights_outlined),
                          color: const Color(0xFF2839A4),
                          splashRadius: 24,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
