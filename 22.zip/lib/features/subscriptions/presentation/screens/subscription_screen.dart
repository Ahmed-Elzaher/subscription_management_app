import 'package:flutter/material.dart';
import 'package:subscription_management/core/utils/app_constants.dart';
import '../../data/models/subscription_model.dart';
import '../widgets/header_card.dart';
import '../widgets/category_selector.dart';
import '../widgets/subscription_list.dart';
import '../../../../core/utils/app_colors.dart';

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  String _selectedCategory = 'All';
  
  // نفترض وجود البيانات هنا كما سبق
  final List<SubscriptionModel> mockSubscriptions = []; 

  List<SubscriptionModel> get _filteredSubscriptions {
    if (_selectedCategory == 'All') return mockSubscriptions;
    return mockSubscriptions.where((sub) => sub.category == _selectedCategory).toList();
  }

  double _calculateTotalSpend() {
    return _filteredSubscriptions.fold(0, (sum, sub) => sum + sub.price);
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: _buildAppBar(context, textTheme),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppConstants.paddingSmall), // استخدام الثابت
            child: Column(
              children: [
                const SizedBox(height: AppConstants.paddingMedium),
                HeaderCard(
                  totalSpend: _calculateTotalSpend(),
                  currency: '\$',
                ),
                const SizedBox(height: AppConstants.paddingSmall),
                CategorySelector(
                  categories: const ['All', 'Entertainment', 'Business'],
                  selectedCategory: _selectedCategory,
                  onCategoryChanged: (cat) => setState(() => _selectedCategory = cat),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: AppConstants.paddingSmall),

          Expanded(
            child: _filteredSubscriptions.isNotEmpty 
                ? SubscriptionList(subscriptions: _filteredSubscriptions)
                : _buildEmptyState(context),
          ),

          _buildQuickStats(context),
        ],
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context, TextTheme textTheme) {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      title: Text(
        'Subscriptions',
        style: textTheme.headlineSmall?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.5,
        ),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: AppConstants.paddingLarge), // استخدام الثابت
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.primaryBlue.withOpacity(0.2), width: 2),
            ),
            child: const CircleAvatar(
              radius: 18,
              backgroundColor: Colors.white,
              child: Icon(Icons.person_outline, color: AppColors.primaryBlue, size: 20),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickStats(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingLarge, 
        AppConstants.paddingMedium, 
        AppConstants.paddingLarge, 
        AppConstants.paddingMedium
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(AppConstants.radiusLarge)), // استخدام الثابت
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, -5),
          )
        ],
      ),
      child: Row(
        children: [
          _StatTile(
            label: 'Active',
            value: '${_filteredSubscriptions.length}',
            icon: Icons.bolt_rounded,
            color: Colors.orange,
          ),
          const VerticalDivider(width: AppConstants.paddingLarge),
          _StatTile(
            label: 'Monthly',
            value: '\$${_calculateTotalSpend().toStringAsFixed(0)}',
            icon: Icons.account_balance_wallet_rounded,
            color: AppColors.primaryBlue,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off_rounded, size: 60, color: Colors.grey[300]),
          const SizedBox(height: AppConstants.paddingSmall),
          Text("No subscriptions found", style: TextStyle(color: Colors.grey[600], fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;

  const _StatTile({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(AppConstants.paddingSmall),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1), 
              borderRadius: BorderRadius.circular(AppConstants.radiusSmall)
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: AppConstants.paddingSmall),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ],
          )
        ],
      ),
    );
  }
}