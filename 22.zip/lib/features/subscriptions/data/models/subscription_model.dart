class SubscriptionModel {
  final String id;
  final String name;
  final double price;
  final String currency;
  final DateTime renewalDate;
  final String category;
  final String iconUrl;
  final bool isActive;

  SubscriptionModel({
    required this.id,
    required this.name,
    required this.price,
    required this.currency,
    required this.renewalDate,
    required this.category,
    required this.iconUrl,
    this.isActive = true,
  });

  /// Calculate days until renewal
  int get daysUntilRenewal {
    return renewalDate.difference(DateTime.now()).inDays;
  }

  /// Format renewal date as a readable string
  String get formattedRenewalDate {
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return '${months[renewalDate.month - 1]} ${renewalDate.day}';
  }

  /// Create a copy with some fields replaced
  SubscriptionModel copyWith({
    String? id,
    String? name,
    double? price,
    String? currency,
    DateTime? renewalDate,
    String? category,
    String? iconUrl,
    bool? isActive,
  }) {
    return SubscriptionModel(
      id: id ?? this.id,
      name: name ?? this.name,
      price: price ?? this.price,
      currency: currency ?? this.currency,
      renewalDate: renewalDate ?? this.renewalDate,
      category: category ?? this.category,
      iconUrl: iconUrl ?? this.iconUrl,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SubscriptionModel &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}
